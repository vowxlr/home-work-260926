﻿
using Microsoft.IdentityModel.Protocols;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using сервер.Framework;
using сервер.Framework.Attributes;
using сервер.Framework.Result;
using сервер.HttpServer.ORM;
using сервер.Models;

namespace сервер.Controllers
{
    [HttpController("user")]
    public class UserController : ControllerBase
    {
        //private string _connectionString = ConfigurationManager.Instance.Settings.Server.ConnectionString;
        [Get("profile")]
        [Authorize]
        public IHttpResult Profile()
        {
            Console.WriteLine(">>> МЕТОД PROFILE ВЫЗВАН");
            return Html("<h1>Личный кабинет</h1>");
        }
        [Get("list")]
        public async Task<IHttpResult> List()
        {
            string connectionString = ConfigurationManager.Instance.Settings.Server.ConnectionString;
            IOrmContext orm = new OrmContext(connectionString);

            IReadOnlyList<User> users = await orm.GetAllAsync<User>("Users");


            return Page("User/List.html", new { Users = users });
        }
    }
}
