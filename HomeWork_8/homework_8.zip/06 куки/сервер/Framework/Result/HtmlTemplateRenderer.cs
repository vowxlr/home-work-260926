﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace сервер.Framework.Result
{
     public class HtmlTemplateRenderer
    {
        public static string Render(string templatePath, object model)
        {
            string fullPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Templates", templatePath);

            if (!File.Exists(fullPath))
            {
                return $"<h1>Ошибка: Файл шаблона не найден по пути {fullPath}</h1>";
            }

            string template = File.ReadAllText(fullPath);

            string result = ProcessTemplate(template, model);

            return result;
        }

        private static string ProcessTemplate(string template, object model)
        {

            MatchCollection matches = Regex.Matches(template, @"\$\{([^}]+)\}");
            foreach (Match match in matches)
            {
                string propName = match.Groups[1].Value;
                object value = GetPropertyValue(model, propName);

                string stringValue = "";
                if (value != null)
                {
                    stringValue = value.ToString();
                }

                template = template.Replace(match.Value, stringValue);
            }

            return template;
        }

        private static object GetPropertyValue(object obj, string propertyName)
        {
            if (obj == null) return null;

            string[] parts = propertyName.Split('.');
            object current = obj;

            foreach (string part in parts)
            {
                if (current == null) return null;

                PropertyInfo prop = current.GetType().GetProperty(part,
                    BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.IgnoreCase);

                if (prop != null)
                {
                    current = prop.GetValue(current);
                }
                else
                {
                    return null;
                }
            }
            return current;
        }
    }
}
