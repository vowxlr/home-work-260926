﻿using System.Net;

namespace CustomHttpServer.Framework
{
    public static class HttpContext
    {
        public static HttpListenerContext Current { get; set; }
    }
}
