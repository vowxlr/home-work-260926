﻿using System;
using System.IO;
using System.Net;
using System.Threading.Tasks;

namespace CustomHttpServer.Framework.Handlers
{
    class StaticFileHandler : Handler
    {
        public override async Task HandleRequest(HttpListenerContext context)
        {
            var request = context.Request;
            Console.WriteLine("[StaticFileHandler] Пришел запрос: " + request.Url.LocalPath);

            string path = request.Url.LocalPath;
            var response = context.Response;

            // 1. Убираем префикс /connection
            if (path.StartsWith("/connection"))
            {
                path = path.Substring("/connection".Length);
            }

            // 2. Декодируем URL (превращаем %20 в пробелы)
            path = Uri.UnescapeDataString(path);

            try
            {
                // Формируем путь к файлу в папке static
                string filePath = Path.Combine(Directory.GetCurrentDirectory(), "static", path.TrimStart('/'));

                // Если это папка, ищем index.html
                if (Directory.Exists(filePath))
                {
                    filePath = Path.Combine(filePath, "index.html");
                }
                // 3. Если файла нет и нет расширения, пробуем добавить .html
                else if (!File.Exists(filePath) && !Path.HasExtension(filePath))
                {
                    string htmlPath = filePath + ".html";
                    if (File.Exists(htmlPath))
                    {
                        filePath = htmlPath;
                    }
                }

                FileInfo fileInfo = new FileInfo(filePath);

                if (!fileInfo.Exists)
                {
                    response.StatusCode = 404;
                    filePath = Path.Combine(Directory.GetCurrentDirectory(), "static", "404.html");
                    fileInfo = new FileInfo(filePath);
                }

                // Определяем тип контента
                switch (fileInfo.Extension.ToLower())
                {
                    case ".html":
                        response.ContentType = "text/html; charset=utf-8";
                        break;
                    case ".css":
                        response.ContentType = "text/css; charset=utf-8";
                        break;
                    case ".js":
                        response.ContentType = "text/javascript; charset=utf-8";
                        break;
                    case ".png":
                        response.ContentType = "image/png";
                        break;
                    case ".ico":
                        response.ContentType = "image/x-icon";
                        break;
                    default:
                        response.ContentType = "application/octet-stream";
                        break;
                }

                byte[] buffer = await File.ReadAllBytesAsync(filePath);
                response.ContentLength64 = buffer.Length;
                using Stream output = response.OutputStream;
                await output.WriteAsync(buffer);
                await output.FlushAsync();

                Console.WriteLine("[StaticFileHandler] Файл успешно отдан: " + filePath);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[StaticFileHandler] Ошибка: {ex.Message}");
                response.StatusCode = 500;
            }
            finally
            {
                context.Response.Close();
            }
        }
    }
}