﻿using System;
using System.Net;
using System.Reflection;
using System.Threading.Tasks;
using CustomHttpServer.Framework.Attributes;

namespace CustomHttpServer.Framework.Handlers
{
    internal class ControllerHandler : Handler
    {
        public override async Task HandleRequest(HttpListenerContext context)
        {
            Console.WriteLine("[ControllerHandler] Начало");

            var request = context.Request;
            var response = context.Response;
            string path = request.Url.LocalPath;

            Console.WriteLine("[ControllerHandler] path = " + path);

            bool isFile = false;
            if (path.Contains("."))
                isFile = true;

            if (!isFile)
            {
                Console.WriteLine("[ControllerHandler] Это не файл — ищем контроллер");

                string[] rawSegments = request.Url.Segments;
                string[] strParams = new string[rawSegments.Length];

                for (int i = 0; i < rawSegments.Length; i++)
                {
                    strParams[i] = rawSegments[i].Replace("/", "");
                }

                int paramCount = strParams.Length - 2;

                if (paramCount < 1)
                {
                    Console.WriteLine("[ControllerHandler] Недостаточно параметров");
                    if (Successor != null) await Successor.HandleRequest(context);
                    return;
                }

                string[] cleanParams = new string[paramCount];
                for (int i = 0; i < paramCount; i++)
                {
                    cleanParams[i] = strParams[i + 2];
                }

                string controllerName = cleanParams[0];
                Console.WriteLine("[ControllerHandler] controllerName = " + controllerName);

                Assembly assembly = Assembly.GetExecutingAssembly();
                Type[] allTypes = assembly.GetTypes();
                Type controllerType = null;

                Console.WriteLine("[ControllerHandler] Всего типов: " + allTypes.Length);

                for (int i = 0; i < allTypes.Length; i++)
                {
                    Type t = allTypes[i];
                    bool hasAttribute = Attribute.IsDefined(t, typeof(HttpControllerAttribute));

                    if (hasAttribute)
                    {
                        Console.WriteLine("[ControllerHandler] Найден контроллер: " + t.Name);
                        string className = t.Name.ToLower();

                        if (className == controllerName.ToLower() + "controller")
                        {
                            controllerType = t;
                            break;
                        }
                    }
                }

                if (controllerType == null)
                {
                    Console.WriteLine("[ControllerHandler] Контроллер не найден: " + controllerName);
                    if (Successor != null) await Successor.HandleRequest(context);
                    return;
                }

                // ⬇️⬇️⬇️ ЭТО ГЛАВНОЕ ИСПРАВЛЕНИЕ ⬇️⬇️⬇️
                string expectedAttributeName = "";
                if (context.Request.HttpMethod == "GET")
                    expectedAttributeName = "GetAttribute";
                else if (context.Request.HttpMethod == "POST")
                    expectedAttributeName = "PostAttribute";

                Console.WriteLine("[ControllerHandler] Ищем атрибут: " + expectedAttributeName);

                MethodInfo[] methods = controllerType.GetMethods();
                MethodInfo method = null;

                for (int i = 0; i < methods.Length; i++)
                {
                    MethodInfo m = methods[i];
                    object[] attrs = m.GetCustomAttributes(true);

                    for (int j = 0; j < attrs.Length; j++)
                    {
                        string attrName = attrs[j].GetType().Name;

                        if (attrName == expectedAttributeName)
                        {
                            method = m;
                            break;
                        }
                    }

                    if (method != null)
                        break;
                }

                if (method == null)
                {
                    Console.WriteLine("[ControllerHandler] Метод не найден для " + context.Request.HttpMethod);
                    if (Successor != null) await Successor.HandleRequest(context);
                    return;
                }

                Console.WriteLine("[ControllerHandler] Найден метод: " + method.Name);

                HttpContext.Current = context;
                object controllerInstance = Activator.CreateInstance(controllerType);

                ParameterInfo[] parameters = method.GetParameters();
                object[] args = new object[parameters.Length];

                for (int i = 0; i < parameters.Length; i++)
                {
                    Type paramType = parameters[i].ParameterType;

                    if (context.Request.HttpMethod == "POST")
                    {
                        // Для POST параметры приходят в теле — передаём пустые значения
                        if (paramType == typeof(string))
                            args[i] = "";
                        else
                            args[i] = Activator.CreateInstance(paramType);
                    }
                    else
                    {
                        int paramIndex = i + 1;
                        if (paramIndex < cleanParams.Length)
                        {
                            args[i] = Convert.ChangeType(cleanParams[paramIndex], paramType);
                        }
                        else
                        {
                            if (paramType == typeof(string))
                                args[i] = "";
                            else
                                args[i] = Activator.CreateInstance(paramType);
                        }
                    }
                }

                Console.WriteLine("[ControllerHandler] Вызываем метод");
                method.Invoke(controllerInstance, args);
                Console.WriteLine("[ControllerHandler] Обработан контроллер: " + controllerName);
            }
            else
            {
                Console.WriteLine("[ControllerHandler] Это файл — передаём дальше");
                if (Successor != null) await Successor.HandleRequest(context);
            }
        }
    }
}