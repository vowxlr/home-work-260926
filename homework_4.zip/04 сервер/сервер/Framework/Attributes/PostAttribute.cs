﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomHttpServer.Framework.Attributes
{
    public class PostAttribute : Attribute
    {
        public string Route { get; set; }

        public PostAttribute(string route)
        {
            Route = route;
        }
    }
}
