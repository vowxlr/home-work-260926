﻿using CustomHttpServer.Framework;
using CustomHttpServer.Framework.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace сервер.Controllers
{
    [HttpController("tickets")]
    internal class TicketController
    {
        private static List<TicketItem> _tickets = new List<TicketItem>();
        private static int _nextId = 1;

        [Get("")]
        public void GetList()
        {
            HttpListenerRequest request = HttpContext.Current.Request;
            HttpListenerResponse response = HttpContext.Current.Response;

            string category = request.QueryString["category"];
            string status = request.QueryString["status"];
            string categoryFilter = request.QueryString["category"];

            List<TicketItem> filteredList = TicketLogic.FilterTickets(_tickets, categoryFilter);

            StringBuilder html = new StringBuilder();
            html.Append("<html><head><meta charset='utf-8'></head><body>");
            html.Append("<h1>Список обращений</h1>");
            html.Append("<a href='/connection/tickets-create.html'>Создать обращение</a><br><br>");

            if (filteredList.Count == 0)
            {
                html.Append("<p>Таких обращений нет</p>");
            }
            else
            {
                html.Append("<ul>");
                for (int i = 0; i < filteredList.Count; i++)
                {
                    TicketItem t = filteredList[i];

                    string safeSubject = WebUtility.HtmlEncode(t.Subject);

                    html.Append("<li>[" + t.Category + "] <b>" + safeSubject + "</b> (Статус: " + t.Status + ") ");
                    html.Append("<a href='/connection/tickets/details?id=" + t.Id + "'>Подробнее</a></li>");
                }
                html.Append("</ul>");
            }
            html.Append("</body></html>");

            SendResponse(response, 200, html.ToString());
        }
        private void SendResponse(HttpListenerResponse response, int statusCode, string content)
        {
            byte[] buffer = Encoding.UTF8.GetBytes(content);
            response.StatusCode = statusCode;
            response.ContentType = "text/html; charset=utf-8";
            response.ContentLength64 = buffer.Length;

            Stream output = response.OutputStream;
            output.Write(buffer, 0, buffer.Length);
            output.Close();
            response.Close();
        }
    }
}
