﻿using System.Net;

namespace сервер.Framework.Result
{
    public interface IHttpResult
    {
        Task ExecuteAsync(HttpListenerResponse response);
    }
}