﻿using System.Net;

namespace сервер.Framework.Handlers
{
    public static class HttpContext
    {
        public static HttpListenerContext Current { get; set; }
    }
}
