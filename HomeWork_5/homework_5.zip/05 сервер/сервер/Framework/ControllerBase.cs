﻿using System.IO;
using System.Net;
using System.Text;

namespace CustomHttpServer.Framework
{
    public abstract class ControllerBase
    {
        // Доступ к текущему запросу и ответу через HttpContext.Current
        protected HttpListenerContext Context
        {
            get { return HttpContext.Current; }
        }

        // Хелпер для отправки HTML-ответа
        protected void SendHtml(string html)
        {
            var response = HttpContext.Current.Response;
            byte[] buffer = Encoding.UTF8.GetBytes(html);
            response.ContentType = "text/html; charset=utf-8";
            response.ContentLength64 = buffer.Length;
            response.OutputStream.Write(buffer, 0, buffer.Length);
            response.OutputStream.Close();
        }
    }
}
