﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace сервер.HttpServer.ORM
{
    internal class OrmContext : IOrmContext
    {
        private readonly string _connectionString;
        public OrmContext(string connectionString)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(
                connectionString);

            _connectionString = connectionString;
        }
        public async Task<IReadOnlyList<T>> GetAllAsync<T>(
       string tableName,
       CancellationToken cancellationToken = default)
       where T : class, new()
        {
            string safeTableName = EscapeIdentifier(tableName);

            string sql = $"SELECT * FROM {safeTableName}";

            var result = new List<T>();

            await using var connection =
                new SqlConnection(_connectionString);

            await connection.OpenAsync(cancellationToken);

            await using var command =
                new SqlCommand(sql, connection);

            await using var reader =
                await command.ExecuteReaderAsync(cancellationToken);

            PropertyInfo[] properties = typeof(T)
                .GetProperties(BindingFlags.Public |
                               BindingFlags.Instance)
                .Where(property => property.CanWrite &&
                                   property.SetMethod?.IsPublic == true)
                .ToArray();

            var columns = new Dictionary<string, int>(
                StringComparer.OrdinalIgnoreCase);

            for (int index = 0; index < reader.FieldCount; index++)
            {
                columns[reader.GetName(index)] = index;
            }

            while (await reader.ReadAsync(cancellationToken))
            {
                T entity = new();

                foreach (PropertyInfo property in properties)
                {
                    if (!columns.TryGetValue(
                            property.Name, out int ordinal))
                    {
                        continue;
                    }

                    if (await reader.IsDBNullAsync(
                            ordinal, cancellationToken))
                    {
                        if (!property.PropertyType.IsValueType ||
                            Nullable.GetUnderlyingType(
                                property.PropertyType) != null)
                        {
                            property.SetValue(entity, null);
                        }

                        continue;
                    }

                    object value = reader.GetValue(ordinal);

                    Type targetType =
                        Nullable.GetUnderlyingType(
                            property.PropertyType)
                        ?? property.PropertyType;

                    object convertedValue =
                        targetType.IsInstanceOfType(value)
                            ? value
                            : targetType.IsEnum
                                ? Enum.ToObject(targetType, value)
                                : Convert.ChangeType(
                                    value,
                                    targetType,
                                    CultureInfo.InvariantCulture);

                    property.SetValue(entity, convertedValue);
                }

                result.Add(entity);
            }

            return result;
        }
        private static string EscapeIdentifier(string identifier)
        {
            if (string.IsNullOrWhiteSpace(identifier) ||
                !Regex.IsMatch(
                    identifier,
                    @"^[A-Za-z_][A-Za-z0-9_]*$"))
            {
                throw new ArgumentException(
                    "Недопустимое имя SQL-идентификатора.",
                    nameof(identifier));
            }

            return $"[{identifier}]";
        }

        public async Task<int> InsertAsync<T>(string tableName, T entity, CancellationToken cancellationToken = default) where T : class
        {
            string safeTableName = EscapeIdentifier(tableName);
            PropertyInfo[] properties = typeof(T).GetProperties();

            List<string> columnNames = new List<string>();
            List<string> paramNames = new List<string>();

            // Собираем имена столбцов, пропуская Id
            for (int i = 0; i < properties.Length; i++)
            {
                if (properties[i].Name == "Id") continue; // Пропускаем первичный ключ

                columnNames.Add(EscapeIdentifier(properties[i].Name));
                paramNames.Add("@" + properties[i].Name);
            }

            string sql = $"INSERT INTO {safeTableName} ({string.Join(", ", columnNames)}) VALUES ({string.Join(", ", paramNames)})";

            await using var connection = new SqlConnection(_connectionString);
            await connection.OpenAsync(cancellationToken);
            await using var command = new SqlCommand(sql, connection);

            for (int i = 0; i < properties.Length; i++)
            {
                if (properties[i].Name == "Id") continue;

                object value = properties[i].GetValue(entity);
                command.Parameters.AddWithValue("@" + properties[i].Name, value ?? DBNull.Value);
            }

            return await command.ExecuteNonQueryAsync(cancellationToken);
        }

        public async Task<int> UpdateAsync<T>(string tableName, int id, T entity, CancellationToken cancellationToken = default) where T : class
        {
            string safeTableName = EscapeIdentifier(tableName);
            PropertyInfo[] properties = typeof(T).GetProperties();

            List<string> setClauses = new List<string>();

            for (int i = 0; i < properties.Length; i++)
            {
                if (properties[i].Name == "Id") continue;
                setClauses.Add($"{EscapeIdentifier(properties[i].Name)} = @{properties[i].Name}");
            }

            string sql = $"UPDATE {safeTableName} SET {string.Join(", ", setClauses)} WHERE [Id] = @Id";

            await using var connection = new SqlConnection(_connectionString);
            await connection.OpenAsync(cancellationToken);
            await using var command = new SqlCommand(sql, connection);

            for (int i = 0; i < properties.Length; i++)
            {
                if (properties[i].Name == "Id") continue;
                object value = properties[i].GetValue(entity);
                command.Parameters.AddWithValue("@" + properties[i].Name, value ?? DBNull.Value);
            }

            command.Parameters.AddWithValue("@Id", id);

            return await command.ExecuteNonQueryAsync(cancellationToken);
        }

        public async Task<int> DeleteAsync(string tableName, int id, CancellationToken cancellationToken = default)
        {
            string safeTableName = EscapeIdentifier(tableName);

            string sql = $"DELETE FROM {safeTableName} WHERE [Id] = @Id";

            await using var connection = new SqlConnection(_connectionString);
            await connection.OpenAsync(cancellationToken);
            await using var command = new SqlCommand(sql, connection);

            command.Parameters.AddWithValue("@Id", id);

            return await command.ExecuteNonQueryAsync(cancellationToken);
        }
    }
}
