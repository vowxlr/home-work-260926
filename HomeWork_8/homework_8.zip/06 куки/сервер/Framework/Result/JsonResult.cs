﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;


namespace сервер.Framework.Result
{
    public class JsonResult : IHttpResult
    {
        private readonly string _jsonContent;
        private readonly int _statusCode;

        public JsonResult(object data, int statusCode = 200)
        {
            _jsonContent = JsonSerializer.Serialize(data, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            });
            _statusCode = statusCode;
        }

        public async Task ExecuteAsync(HttpListenerResponse response)
        {
            byte[] buffer = Encoding.UTF8.GetBytes(_jsonContent);

            response.StatusCode = _statusCode;
            response.ContentType = "application/json; charset=utf-8";
            response.ContentLength64 = buffer.Length;

            using (var output = response.OutputStream)
            {
                await output.WriteAsync(buffer, 0, buffer.Length);
            }
        }
    }
}
