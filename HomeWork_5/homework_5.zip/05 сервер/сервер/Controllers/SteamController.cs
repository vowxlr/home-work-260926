﻿using System;
using System.Net;
using System.Net.Mail;
using CustomHttpServer.Framework;
using CustomHttpServer.Framework.Attributes;

namespace CustomHttpServer.Controllers
{
    [HttpController("steam")]
    public class SteamController : ControllerBase
    {
        // GET http://localhost:2323/steam/send?to=test@test.ru&hero=
        [Get("send")]
        public void Send([FromQuery] string to, string hero)
        {
            // отправитель - устанавливаем адрес и отображаемое в письме имя
            MailAddress from = new MailAddress("моя почта@gmail.com", "Ekaterina");
            // кому отправляем
            MailAddress toAddress = new MailAddress(to);

            // создаем объект сообщения
            MailMessage message = new MailMessage(from, toAddress);

            // тема письма
            message.Subject = "Тест";

            // текст письма
            message.Body = "<h2>Письмо-тест работы smtp-клиента</h2>";

            // письмо представляет код html
            message.IsBodyHtml = true;

            // адрес smtp-сервера и порт, с которого будем отправлять письмо
            SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587);
            smtp.EnableSsl = true;

            // логин и пароль
            smtp.Credentials = new NetworkCredential("моя почта@gmail.com", "пароль от моей почты");
            smtp.Send(message);
        }
    }
}
