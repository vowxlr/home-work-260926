﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace сервер.Framework.Authentication
{
    public interface IUserSessionService
    {
        string CreateSession(int userId);
        int? GetUserId(string? sessionId);
        void RemoveSession(string? sessionId);
    }
}
