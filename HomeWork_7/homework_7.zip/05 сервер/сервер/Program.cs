﻿using System;
using System.IO;
using System.Text.Json;

namespace MyHttpServer
{
    class Program
    {
        static void Main(string[] args)
        {
            string settingsJson = File.ReadAllText("settings.json");
            Settings settings = JsonSerializer.Deserialize<Settings>(settingsJson);

            HttpServer server = new HttpServer(settings);
            server.Start();

            Console.WriteLine("Введите 'stop' для завершения работы сервера:");

            string command = "";
            while (command != "stop")
            {
                command = Console.ReadLine()?.ToLower();
            }

            server.Stop();
        }
    }
}