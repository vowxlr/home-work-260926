﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading.Tasks; // Не хватает на скриншоте, но нужно для Task

namespace CustomHttpServer.Framework.Handlers
{
    abstract class Handler
    {
        public Handler Successor { get; set; }
        public abstract Task HandleRequest(HttpListenerContext context);
    }
}
