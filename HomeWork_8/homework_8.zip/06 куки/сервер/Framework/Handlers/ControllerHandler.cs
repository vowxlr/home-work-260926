﻿using System;
using System.Net;
using System.Reflection;
using System.Threading.Tasks;
using сервер.Framework.Attributes;
using сервер.Framework.Authentication;
using сервер.Framework.Handlers;
using сервер.Framework.Result;

namespace сервер.Framework.Handlers
{
    internal class ControllerHandler : Handler
    {
        private readonly IUserSessionService _sessionService;
        public ControllerHandler(IUserSessionService sessionService)
        {
            _sessionService = sessionService;
        }
        private bool IsAuthorized(HttpListenerContext context,Type controllerType,MethodInfo method)
        {
            bool requiresAuthorization =
                controllerType.IsDefined(
                    typeof(AuthorizeAttribute), true)
                || method.IsDefined(
                    typeof(AuthorizeAttribute), true);

            if (!requiresAuthorization)
            {
                return true;
            }

            string? sessionId =
                context.Request.Cookies["sessionId"]?.Value;

            int? userId =
                _sessionService.GetUserId(sessionId);

            return userId.HasValue;
        }
        public override async Task HandleRequest(HttpListenerContext context)
        {

            Console.WriteLine("[ControllerHandler] Начало");

            var request = context.Request;
            var response = context.Response;
            string path = request.Url.LocalPath;

            Console.WriteLine("[ControllerHandler] path = " + path);

            bool isFile = false;
            if (path.Contains("."))
                isFile = true;

            if (!isFile)
            {
                Console.WriteLine("[ControllerHandler] Это не файл — ищем контроллер");

                string[] rawSegments = request.Url.Segments;
                string[] strParams = new string[rawSegments.Length];

                for (int i = 0; i < rawSegments.Length; i++)
                {
                    strParams[i] = rawSegments[i].Replace("/", "");
                }

                int paramCount = strParams.Length - 2;

                if (paramCount < 1)
                {
                    Console.WriteLine("[ControllerHandler] Недостаточно параметров");
                    if (Successor != null) await Successor.HandleRequest(context);
                    return;
                }

                string[] cleanParams = new string[paramCount];
                for (int i = 0; i < paramCount; i++)
                {
                    cleanParams[i] = strParams[i + 2];
                }

                string controllerName = cleanParams[0];
                Console.WriteLine("[ControllerHandler] controllerName = " + controllerName);

                Assembly assembly = Assembly.GetExecutingAssembly();
                Type[] allTypes = assembly.GetTypes();
                Type controllerType = null;

                Console.WriteLine("[ControllerHandler] Всего типов: " + allTypes.Length);

                for (int i = 0; i < allTypes.Length; i++)
                {
                    Type t = allTypes[i];
                    bool hasAttribute = Attribute.IsDefined(t, typeof(HttpControllerAttribute));

                    if (hasAttribute)
                    {
                        Console.WriteLine("[ControllerHandler] Найден контроллер: " + t.Name);
                        string className = t.Name.ToLower();

                        if (className == controllerName.ToLower() + "controller")
                        {
                            controllerType = t;
                            break;
                        }
                    }
                }

                if (controllerType == null)
                {
                    Console.WriteLine("[ControllerHandler] Контроллер не найден: " + controllerName);
                    if (Successor != null) await Successor.HandleRequest(context);
                    return;
                }

                string expectedAttributeName = "";
                if (context.Request.HttpMethod == "GET")
                    expectedAttributeName = "GetAttribute";
                else if (context.Request.HttpMethod == "POST")
                    expectedAttributeName = "PostAttribute";
                else if (context.Request.HttpMethod == "PUT")
                    expectedAttributeName = "PutAttribute";

                Console.WriteLine("[ControllerHandler] Ищем атрибут: " + expectedAttributeName);

                MethodInfo[] methods = controllerType.GetMethods();
                MethodInfo method = null;

                for (int i = 0; i < methods.Length; i++)
                {
                    MethodInfo m = methods[i];
                    object[] attrs = m.GetCustomAttributes(true);

                    for (int j = 0; j < attrs.Length; j++)
                    {
                        string attrName = attrs[j].GetType().Name;

                        if (attrName == expectedAttributeName)
                        {
                            method = m;
                            break;
                        }
                    }

                    if (method != null)
                        break;
                }

                if (method == null)
                {
                    Console.WriteLine("[ControllerHandler] Метод не найден для " + context.Request.HttpMethod);
                    if (Successor != null) await Successor.HandleRequest(context);
                    return;
                }

                Console.WriteLine("[ControllerHandler] Найден метод: " + method.Name);

                HttpContext.Current = context;
                object controllerInstance = Activator.CreateInstance(controllerType);

                ParameterInfo[] parameters = method.GetParameters();
                object[] args = new object[parameters.Length];

                Dictionary<string, string> formData = new Dictionary<string, string>();
                if (context.Request.HttpMethod == "POST" && context.Request.HasEntityBody)
                {
                    using (StreamReader reader = new StreamReader(context.Request.InputStream, context.Request.ContentEncoding))
                    {
                        string body = reader.ReadToEnd();
                        Console.WriteLine("[DEBUG] Сырое тело запроса: " + body); // <-- ВЫВЕДЕТ ТО, ЧТО ПРИШЛО ОТ БРАУЗЕРА
                        if (!string.IsNullOrEmpty(body))
                        {
                            string[] pairs = body.Split('&');
                            for (int p = 0; p < pairs.Length; p++)
                            {
                                string[] parts = pairs[p].Split('=');
                                if (parts.Length == 2)
                                {
                                    string key = Uri.UnescapeDataString(parts[0]);
                                    string val = Uri.UnescapeDataString(parts[1].Replace('+', ' '));
                                    formData[key] = val;
                                }
                            }
                        }
                    }
                }
               
                object[] args1 = new object[parameters.Length];

                for (int i = 0; i < parameters.Length; i++)
                {
                    Type paramType = parameters[i].ParameterType;
                    string paramName = parameters[i].Name; 

                    if (context.Request.HttpMethod == "POST")
                    {
                        // Ищем значение в данных из формы
                        if (formData.ContainsKey(paramName))
                        {
                            string value = formData[paramName];
                            
                            args1[i] = Convert.ChangeType(value, paramType);
                        }
                        else
                        {
                           
                            if (paramType == typeof(string)) args1[i] = "";
                            else args1[i] = Activator.CreateInstance(paramType);
                        }
                    }
                    else 
                    {
                        int paramIndex = i + 1;
                        if (paramIndex < cleanParams.Length)
                        {
                            args1[i] = Convert.ChangeType(cleanParams[paramIndex], paramType);
                        }
                        else
                        {
                            if (paramType == typeof(string)) args1[i] = "";
                            else args1[i] = Activator.CreateInstance(paramType);
                        }
                    }
                }

                for (int i = 0; i < parameters.Length; i++)
                {
                    ParameterInfo p = parameters[i];
                    Type paramType = p.ParameterType;

                    bool isFromQuery = false;
                    object[] paramAttrs = p.GetCustomAttributes(true);

                    for (int k = 0; k < paramAttrs.Length; k++)
                    {
                        if (paramAttrs[k].GetType().Name == "FromQueryAttribute")
                        {
                            isFromQuery = true;
                            break;
                        }
                    }

                    if (isFromQuery)
                    {
                        string queryValue = context.Request.QueryString[p.Name];

                        if (queryValue == null)
                            queryValue = "";

                        args[i] = queryValue;
                    }
                    else if (context.Request.HttpMethod == "POST")
                    {
                        if (paramType == typeof(string))
                            args[i] = "";
                        else
                            args[i] = Activator.CreateInstance(paramType);
                    }
                    else
                    {
                        int paramIndex = i + 1;

                        if (paramIndex < cleanParams.Length)
                        {
                            args[i] = Convert.ChangeType(cleanParams[paramIndex], paramType);
                        }
                        else
                        {
                            if (paramType == typeof(string))
                                args[i] = "";
                            else
                                args[i] = Activator.CreateInstance(paramType);
                        }
                    }
                }

                Console.WriteLine("[ControllerHandler] Вызываем метод");

                if (!IsAuthorized(context, controllerType, method))
                {
                    context.Response.StatusCode = 401;
                    context.Response.Close();
                    return;
                }

                Console.WriteLine("[ControllerHandler] Вызываем метод");

                object result = method.Invoke(controllerInstance, args);

                if (result is IHttpResult httpResult)
                {
                    await httpResult.ExecuteAsync(context.Response);
                }

                Console.WriteLine("[ControllerHandler] Обработан контроллер: " + controllerName);
                Console.WriteLine("[ControllerHandler] Обработан контроллер: " + controllerName);
            }
            else
            {
                Console.WriteLine("[ControllerHandler] Это файл — передаём дальше");
                if (Successor != null) await Successor.HandleRequest(context);
            }
        }
    }
}