﻿
using System;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using сервер.Framework.Attributes;
using сервер.Framework.Handlers;
using сервер.Controllers;
using сервер.Framework.Result;
using сервер.Services.Authentication;

namespace сервер.Framework.Handlers
{
    [HttpController("auth")]
    public class AuthController : ControllerBase
    {
        [Post("login")]
        public IHttpResult Login(string login, string password)
        {
            Console.WriteLine($"[DEBUG] Пришло: login='{login}', password='{password}'");
            const string testLogin = "student";
            const string testPassword = "test123";

            if (login != testLogin || password != testPassword)
            {
                return Json(new
                {
                    Success = false,
                    Message = "Неверный логин или пароль"
                });
            }

            int userId = 1;
            string sessionId = SessionService.CreateSession(userId);

            var cookie = new Cookie("sessionId", sessionId, "/")
            {
                HttpOnly = true,
                Expires = DateTime.UtcNow.AddMinutes(30)
            };

            Context.Response.SetCookie(cookie);

            return Json(new
            {
                Success = true,
                Message = "Вход выполнен"
            });
        }

        [Post("logout")]
        public IHttpResult Logout()
        {
            string? sessionId = Context.Request.Cookies["sessionId"]?.Value;

            SessionService.RemoveSession(sessionId);

            var cookie = new Cookie("sessionId", string.Empty, "/")
            {
                HttpOnly = true,
                Expires = DateTime.UtcNow.AddDays(-1)
            };

            Context.Response.SetCookie(cookie);

            return Json(new
            {
                Success = true,
                Message = "Выход выполнен"
            });
        }
        [Get("login")]
        public IHttpResult LoginPage()
        {
            string html = @"
            <!DOCTYPE html>
            <html>
            <head>
            <meta charset='utf-8'>
            <title>Вход в систему</title>
            </head>
            <body>
            <h2>Вход в систему</h2>
            <form action='/connection/auth/login' method='POST'>
            <label>Логин: <input type='text' name='login' required></label><br><br>
            <label>Пароль: <input type='password' name='password' required></label><br><br>
            <button type='submit'>Войти</button>
            </form>
            </body>
            </html>";

            return Html(html);
        }

        [Post("login")]
        public void login(string email, string password)
        {
            var context = HttpContext.Current;
            var request = context.Request;
            var response = context.Response;

            
            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                using (var reader = new StreamReader(request.InputStream, request.ContentEncoding))
                {
                    string body = reader.ReadToEnd();
                    if (!string.IsNullOrEmpty(body))
                    {
                        string[] pairs = body.Split('&');
                        foreach (string pair in pairs)
                        {
                            
                            int idx = pair.IndexOf('=');
                            if (idx > 0)
                            {
                                string key = Uri.UnescapeDataString(pair.Substring(0, idx));
                                string value = Uri.UnescapeDataString(pair.Substring(idx + 1));

                                if (key == "email") email = value;
                                if (key == "password") password = value;
                            }
                        }
                    }
                }
            }

            if (string.IsNullOrEmpty(email))
                email = request.QueryString["email"];

            if (string.IsNullOrEmpty(password))
                password = request.QueryString["password"];

            Console.WriteLine("=== Данные из формы ===");
            Console.WriteLine("Login: " + email);
            Console.WriteLine("Password: " + password);

            string html = "<h1>Добро пожаловать, " + email + "!</h1>";
            byte[] buffer = Encoding.UTF8.GetBytes(html);
            response.ContentType = "text/html; charset=utf-8";
            response.ContentLength64 = buffer.Length;
            response.OutputStream.Write(buffer, 0, buffer.Length);
            response.OutputStream.Close();
        }
    }
}
