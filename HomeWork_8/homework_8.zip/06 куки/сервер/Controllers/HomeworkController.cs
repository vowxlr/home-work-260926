﻿using System;
using System.IO;
using System.Net;
using System.Net.Mail;
using сервер.Framework.Attributes;

namespace сервер.Controllers
{
    [HttpController("homework")]
    public class HomeworkController : ControllerBase
    {
        //http:// 127.0.0.1:9999/connection/homework/send?to=
        [Get("send")]
        public void Send([FromQuery] string to)
        {
            try
            {
                string myEmail = "hwork67.owo@yandex.ru";
                string myAppPassword = "bzieimkjkegeusko";

                MailAddress from = new MailAddress(myEmail, "Сырайкина Екатерина");
                MailAddress toAddress = new MailAddress(to);

                MailMessage message = new MailMessage(from, toAddress);
                message.Subject = "Домашнее задание";

                message.Body = "<h2>Домашняя работа</h2>" +
                               "<p><b>Группа:</b> 11-541</p>" +
                               "<p><b>ФИО:</b> Сырайкина Екатерина Андреевна</p>";
                message.IsBodyHtml = true;

                // Путь к zip-файлу. 
                string zipPath = Path.Combine(Directory.GetCurrentDirectory(), "static", "zip_failes", "homework_5.zip");

                if (File.Exists(zipPath))
                {
                    Attachment attachment = new Attachment(zipPath);
                    message.Attachments.Add(attachment);
                }
                else
                {
                    Console.WriteLine("Внимание: Zip-файл не найден по пути " + zipPath);
                }


                SmtpClient smtp = new SmtpClient("smtp.yandex.ru", 587);
                smtp.EnableSsl = true;
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;

                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new NetworkCredential(myEmail, myAppPassword);

                smtp.Send(message);
                Console.WriteLine("Письмо успешно отправлено на " + to);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка при отправке письма: " + ex.Message);
            }
        }
    }
}
