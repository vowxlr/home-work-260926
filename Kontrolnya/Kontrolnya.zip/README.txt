апустить программу и вбить в поиск:
http://127.0.0.1:9999/connection/tickets-create.html