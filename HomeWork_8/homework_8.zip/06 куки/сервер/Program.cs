﻿using System;
using System.IO;
using System.Text.Json;
using сервер;
using сервер.Framework.Authentication;
using сервер.Framework.Handlers;
using сервер.Services.Authentication;

namespace MyHttpServer
{
    class Program
    {
        static void Main(string[] args)
        {

            string settingsJson = File.ReadAllText("settings.json");
            Settings settings = JsonSerializer.Deserialize<Settings>(settingsJson);
            ConfigurationManager.Instance.Settings = settings;

            IUserSessionService sessionService = new UserSessionService();
            var controllerHandler = new ControllerHandler(sessionService);

            HttpServer server = new HttpServer(settings, sessionService);
            server.Start();

            Console.WriteLine("Введите 'stop' для завершения работы сервера:");

            string command = "";
            while (command != "stop")
            {
                command = Console.ReadLine()?.ToLower();
            }


            server.Stop();
        }
    }
}