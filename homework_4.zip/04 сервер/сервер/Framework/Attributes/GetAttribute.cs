﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomHttpServer.Framework.Attributes
{
    public class GetAttribute : Attribute
    {
        public string Route { get; set; }

        public GetAttribute(string route)
        {
            Route = route;
        }
    }
}
