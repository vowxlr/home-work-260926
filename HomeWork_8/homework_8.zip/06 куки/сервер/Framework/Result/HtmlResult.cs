﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace сервер.Framework.Result
{
    public class HtmlResult : IHttpResult
    {
        private readonly string _htmlContent;
        private readonly int _statusCode;

        public HtmlResult(string htmlContent, int statusCode = 200)
        {
            _htmlContent = htmlContent;
            _statusCode = statusCode;
        }

        public async Task ExecuteAsync(HttpListenerResponse response)
        {
            byte[] buffer = Encoding.UTF8.GetBytes(_htmlContent);
            response.StatusCode = _statusCode;
            response.ContentType = "text/html; charset=utf-8";
            response.ContentLength64 = buffer.Length;

            using (var output = response.OutputStream)
            {
                await output.WriteAsync(buffer, 0, buffer.Length);
            }
        }
    }
}
