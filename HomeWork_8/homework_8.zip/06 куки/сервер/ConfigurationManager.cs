﻿using MyHttpServer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace сервер
{
    public class ConfigurationManager
    {
        public static ConfigurationManager Instance { get; } = new ConfigurationManager();

        public Settings Settings { get; set; }

        private ConfigurationManager()
        {

        }

        public void Load(string settingsJson)
        {
            Settings = JsonSerializer.Deserialize<Settings>(settingsJson);
        }
    }
}
