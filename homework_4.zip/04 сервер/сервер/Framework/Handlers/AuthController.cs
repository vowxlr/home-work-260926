﻿using CustomHttpServer.Framework;
using CustomHttpServer.Framework.Attributes;
using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace CustomHttpServer.Controllers
{
    [HttpController("auth")]
    internal class AuthController
    {
        [Get("login")]
        public void login()
        {
            var response = HttpContext.Current.Response;

            // Путь к файлу login.html
            string filePath = Path.Combine(
                Directory.GetCurrentDirectory(),
                "static",
                "Login Form",
                "login.html"
            );

            if (File.Exists(filePath))
            {
                byte[] buffer = File.ReadAllBytes(filePath);
                response.ContentType = "text/html; charset=utf-8";
                response.ContentLength64 = buffer.Length;
                response.OutputStream.Write(buffer, 0, buffer.Length);
            }
            else
            {
                response.StatusCode = 404;
                byte[] buffer = Encoding.UTF8.GetBytes("<h1>404 - login.html не найден</h1>");
                response.ContentType = "text/html; charset=utf-8";
                response.ContentLength64 = buffer.Length;
                response.OutputStream.Write(buffer, 0, buffer.Length);
            }

            response.OutputStream.Close();
        }

        [Post("login")]
        public void login(string email, string password)
        {
            var context = HttpContext.Current;
            var request = context.Request;
            var response = context.Response;

            // Если параметры не пришли из URL — читаем из тела запроса (form-data)
            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                using (var reader = new StreamReader(request.InputStream, request.ContentEncoding))
                {
                    string body = reader.ReadToEnd();
                    if (!string.IsNullOrEmpty(body))
                    {
                        string[] pairs = body.Split('&');
                        foreach (string pair in pairs)
                        {
                            // Ищем первый знак '=', чтобы корректно обработать пароли с '=' внутри
                            int idx = pair.IndexOf('=');
                            if (idx > 0)
                            {
                                string key = Uri.UnescapeDataString(pair.Substring(0, idx));
                                string value = Uri.UnescapeDataString(pair.Substring(idx + 1));

                                if (key == "email") email = value;
                                if (key == "password") password = value;
                            }
                        }
                    }
                }
            }

            // Если всё ещё пусто — пробуем query string
            if (string.IsNullOrEmpty(email))
                email = request.QueryString["email"];

            if (string.IsNullOrEmpty(password))
                password = request.QueryString["password"];

            // Вывод в консоль
            Console.WriteLine("=== Данные из формы ===");
            Console.WriteLine("Login: " + email);
            Console.WriteLine("Password: " + password);

            // Ответ пользователю
            string html = "<h1>Добро пожаловать, " + email + "!</h1>";
            byte[] buffer = Encoding.UTF8.GetBytes(html);
            response.ContentType = "text/html; charset=utf-8";
            response.ContentLength64 = buffer.Length;
            response.OutputStream.Write(buffer, 0, buffer.Length);
            response.OutputStream.Close();
        }
    }
}
