﻿using System;
using System.IO;
using System.Net;
using System.Text.Json;
using System.Threading.Tasks;
using CustomHttpServer.Framework.Handlers;

namespace MyHttpServer
{
    public class HttpServer
    {
        private Handler _firstHandler;
        private readonly HttpListener _listener;
        private readonly string _urlPrefix;
        private readonly string _normalizedPath;
        private readonly string _staticFolder;
        private bool _isRunning;

        public HttpServer(Settings settings)
        {
            _listener = new HttpListener();

            _normalizedPath = settings.Server.Path.Trim('/');
            _urlPrefix = "http://" + settings.Server.Host + ":" + settings.Server.Port + "/" + _normalizedPath + "/";
            _listener.Prefixes.Add(_urlPrefix);

            _staticFolder = Path.Combine(Directory.GetCurrentDirectory(), "static");
        }


        public void Start()
        {
            _isRunning = true;
            _listener.Start();
            Console.WriteLine("Сервер запущен и слушает: " + _urlPrefix);
            Console.WriteLine("Папка с сайтами: " + _staticFolder);
            Receive();
        }

        public void Stop()
        {
            _isRunning = false;
            _listener.Stop();
            _listener.Close();
            Console.WriteLine("Сервер корректно остановлен.");
        }

        private void Receive()
        {
            if (_isRunning)
            {
                _listener.BeginGetContext(ListenerCallback, _listener);
            }
        }

        private void ListenerCallback(IAsyncResult result)
        {
            if (!_isRunning) return;

            HttpListenerContext context = _listener.EndGetContext(result);
            Console.WriteLine("Пришёл запрос: " + context.Request.Url.LocalPath);

            _ = ProcessRequest(context);
            Receive();
        }

        private async Task ProcessRequest(HttpListenerContext context)
        {
            try
            {
                // Создаём цепочку обработчиков
                ControllerHandler controllerHandler = new ControllerHandler();
                StaticFileHandler staticFileHandler = new StaticFileHandler();
                controllerHandler.Successor = staticFileHandler;

                // Запускаем обработку
                await controllerHandler.HandleRequest(context);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка при обработке запроса: " + ex.Message);
            }
        }
    }
}