﻿using System;
using System.IO;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace MyHttpServer
{
    public class HttpServer
    {
        private readonly HttpListener _listener;
        private readonly string _urlPrefix;
        private readonly string _normalizedPath;
        private readonly string _staticFolder;
        private bool _isRunning;

        public HttpServer(Settings settings)
        {
            _listener = new HttpListener();

            _normalizedPath = settings.Server.Path.Trim('/');
            _urlPrefix = "http://" + settings.Server.Host + ":" + settings.Server.Port + "/" + _normalizedPath + "/";
            _listener.Prefixes.Add(_urlPrefix);

            _staticFolder = Path.Combine(Directory.GetCurrentDirectory(), "static");
        }

        // Логика запуска
        public void Start()
        {
            _isRunning = true;
            _listener.Start();
            Console.WriteLine("Сервер запущен и слушает: " + _urlPrefix);
            Console.WriteLine("Папка с сайтами: " + _staticFolder);
            Receive();
        }

        // Логика остановки
        public void Stop()
        {
            _isRunning = false;
            _listener.Stop();
            _listener.Close();
            Console.WriteLine("Сервер корректно остановлен.");
        }

        // Регистрируем ожидание следующего запроса
        private void Receive()
        {
            if (_isRunning)
            {
                _listener.BeginGetContext(ListenerCallback, _listener);
            }
        }

        // Коллбэк, который срабатывает, когда пришёл запрос
        private void ListenerCallback(IAsyncResult result)
        {
            if (!_isRunning) return;

            HttpListenerContext context = _listener.EndGetContext(result);
            Console.WriteLine("Пришёл запрос: " + context.Request.Url.LocalPath);

            // Обрабатываем запрос (в отдельной задаче, без лямбды)
            Task.Run(delegate { ProcessRequest(context); });

            // Сразу регистрируем ожидание следующего запроса
            Receive();
        }

        // Обработка одного запроса
        private async Task ProcessRequest(HttpListenerContext context)
        {
            HttpListenerResponse response = context.Response;

            try
            {
                string path = context.Request.Url.LocalPath;

                path = Uri.UnescapeDataString(path);

                // Убираем префикс /connection из пути
                string prefix = "/" + _normalizedPath;
                if (path.StartsWith(prefix))
                {
                    path = path.Substring(prefix.Length);
                }

                // Если путь пустой или "/" -> открываем index.html
                if (string.IsNullOrEmpty(path) || path == "/")
                {
                    path = "/index.html";
                }

                // Если путь заканчивается на "/" -> добавляем index.html
                if (path.EndsWith("/"))
                {
                    path = path + "index.html";
                }

                // Полный путь к файлу
                string relativePath = path.TrimStart('/');
                relativePath = relativePath.Replace('/', Path.DirectorySeparatorChar);
                string filePath = Path.Combine(_staticFolder, relativePath);

                // Если файла нет — 404
                if (!File.Exists(filePath))
                {
                    response.StatusCode = 404;
                    string errorPath = Path.Combine(_staticFolder, "404.html");

                    if (File.Exists(errorPath))
                    {
                        filePath = errorPath;
                    }
                    else
                    {
                        byte[] errBuffer = Encoding.UTF8.GetBytes("<h1>404 Not Found</h1>");
                        response.ContentType = "text/html; charset=utf-8";
                        response.ContentLength64 = errBuffer.Length;
                        await response.OutputStream.WriteAsync(errBuffer);
                        response.OutputStream.Close();
                        return;
                    }
                }

                // Определяем тип файла
                string contentType = GetMimeType(filePath);

                // Читаем и отправляем файл
                byte[] buffer = await File.ReadAllBytesAsync(filePath);
                response.ContentType = contentType;
                response.ContentLength64 = buffer.Length;

                using (Stream output = response.OutputStream)
                {
                    await output.WriteAsync(buffer);
                    await output.FlushAsync();
                }

                Console.WriteLine("Запрос обработан");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка при обработке запроса: " + ex.Message);
            }
            finally
            {
                response.Close();
            }
        }

        // Определение Content-Type по расширению файла
        private string GetMimeType(string path)
        {
            string extension = Path.GetExtension(path).ToLower();

            switch (extension)
            {
                case ".html":
                case ".htm":
                    return "text/html; charset=utf-8";
                case ".css":
                    return "text/css; charset=utf-8";
                case ".js":
                    return "text/javascript; charset=utf-8";
                case ".json":
                    return "application/json; charset=utf-8";
                case ".png":
                    return "image/png";
                case ".jpg":
                case ".jpeg":
                    return "image/jpeg";
                case ".gif":
                    return "image/gif";
                case ".webp":
                    return "image/webp";
                case ".svg":
                    return "image/svg+xml";
                case ".ico":
                    return "image/x-icon";
                case ".woff":
                    return "font/woff";
                case ".woff2":
                    return "font/woff2";
                case ".ttf":
                    return "font/ttf";
                case ".otf":
                    return "font/otf";
                case ".mp3":
                    return "audio/mpeg";
                case ".mp4":
                    return "video/mp4";
                case ".webm":
                    return "video/webm";
                case ".txt":
                    return "text/plain; charset=utf-8";
                case ".xml":
                    return "application/xml; charset=utf-8";
                case ".pdf":
                    return "application/pdf";
                case ".zip":
                    return "application/zip";
                default:
                    return "application/octet-stream";
            }
        }
    }
}