﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace сервер.Controllers
{
    internal class TicketLogic
    {
        public static bool IsValidAppeal(string appeal)
        {
            if (string.IsNullOrEmpty(appeal))
            {
                return false;
            }
            else if (appeal.Length < 5 || appeal.Length > 100)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        public static bool IsValidCategory(string category)
        {
            if (category == "network" || category == "software" || category == "hardware")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool IsValidStatus(string status)
        {
            if (status == "open" || status == "closed")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static List<TicketItem> FilterTickets(List<TicketItem> allTickets, string category)
        {
            List<TicketItem> result = new List<TicketItem>();

            if (string.IsNullOrEmpty(category))
            {
                return allTickets;
            }

            for (int i = 0; i < allTickets.Count; i++)
            {
                TicketItem current = allTickets[i];

                if (current.Category == category)
                {
                    result.Add(current);
                }
            }

            return result;
        }
    }
}
