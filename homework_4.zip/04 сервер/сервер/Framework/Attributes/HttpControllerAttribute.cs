﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomHttpServer.Framework.Attributes
{
    public class HttpControllerAttribute : Attribute
    {
        public string Route { get; set; }

        public HttpControllerAttribute(string route)
        {
            Route = route;
        }
    }
}
