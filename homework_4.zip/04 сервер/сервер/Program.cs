﻿using System;
using System.IO;
using System.Text.Json;

namespace MyHttpServer
{
    class Program
    {
        static void Main(string[] args)
        {
            // 1. Чтение и десериализация настроек
            string settingsJson = File.ReadAllText("settings.json");
            Settings settings = JsonSerializer.Deserialize<Settings>(settingsJson);

            // 2. Создание и запуск сервера
            HttpServer server = new HttpServer(settings);
            server.Start();

            Console.WriteLine("Введите 'stop' для завершения работы сервера:");

            // 3. Управление сервером через консоль
            string command = "";
            while (command != "stop")
            {
                command = Console.ReadLine()?.ToLower();
            }

            // 4. Остановка сервера
            server.Stop();
        }
    }
}