﻿using System.IO;
using System.Net;
using System.Text;
using сервер.Framework.Attributes;
using сервер.Framework.Authentication;
using сервер.Framework.Handlers;
using сервер.Framework.Result;

namespace сервер.Controllers
{
    public abstract class ControllerBase
    {
        protected HttpListenerContext Context { get; private set; } = null!;
        protected IUserSessionService SessionService { get; private set; } = null!;
        public void Initialize(HttpListenerContext context, IUserSessionService sessionService)
        {
            Context = context;
            SessionService = sessionService;
        }
        protected void SendHtml(string html)
        {
            var response = HttpContext.Current.Response;
            byte[] buffer = Encoding.UTF8.GetBytes(html);
            response.ContentType = "text/html; charset=utf-8";
            response.ContentLength64 = buffer.Length;
            response.OutputStream.Write(buffer, 0, buffer.Length);
            response.OutputStream.Close();
        }

        protected IHttpResult Page(string templateName, object model)
        {
            return new PageResult(templateName, model);
        }
        protected IHttpResult Html(string htmlContent)
        {
            return new HtmlResult(htmlContent);
        }
        protected IHttpResult Json(object data, int statusCode = 200)
        {
            return new JsonResult(data, statusCode);
        }
    }
}
