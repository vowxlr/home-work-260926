﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace сервер.Framework.Attributes
{
    internal class PutAttribute
    {
        public string Route { get; set; }

        public PutAttribute(string route)
        {
            Route = route;
        }
    }
}
