﻿using System;
using System.Collections.Generic;
using System.Text;

namespace сервер.Framework.Attributes
{
    public class GetAttribute : Attribute
    {
        public string Route { get; set; }

        public GetAttribute(string route)
        {
            Route = route;
        }
    }
}
