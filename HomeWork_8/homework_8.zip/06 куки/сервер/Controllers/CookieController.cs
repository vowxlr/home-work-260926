﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using сервер.Framework.Attributes;
using сервер.Framework.Handlers;
using сервер.Framework.Result;

namespace сервер.Controllers
{
    [HttpController("cookie")]
    public class CookieController : ControllerBase
    {
        [Get("set")]
        public IHttpResult Set()
        {
            var cookie = new Cookie("testCookie", "HelloWorld", "/")
            {
                HttpOnly = true,
                Expires = DateTime.UtcNow.AddMinutes(30)
            };
            HttpContext.Current.Response.SetCookie(cookie);
            return Html("<h1>Cookie установлена</h1>");
        }

        [Get("get")]
        public IHttpResult Get()
        {
            string value = HttpContext.Current.Request.Cookies["testCookie"]?.Value;
            return Json(new { Value = value });
        }

        [Get("delete")]
        public IHttpResult Delete()
        {
            var cookie = new Cookie("testCookie", string.Empty, "/")
            {
                Expires = DateTime.UtcNow.AddDays(-1)
            };
            HttpContext.Current.Response.SetCookie(cookie);
            return Html("<h1>Cookie удалена</h1>");
        }
    }
}
