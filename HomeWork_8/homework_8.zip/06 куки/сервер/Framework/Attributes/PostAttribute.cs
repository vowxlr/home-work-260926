﻿using System;
using System.Collections.Generic;
using System.Text;

namespace сервер.Framework.Attributes
{
    public class PostAttribute : Attribute
    {
        public string Route { get; set; }

        public PostAttribute(string route)
        {
            Route = route;
        }
    }
}
