﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace сервер.Framework.Result
{
    public class PageResult : IHttpResult
    {
        private readonly string _templateName;
        private readonly object _model;

        public PageResult(string templateName, object model)
        {
            _templateName = templateName;
            _model = model;
        }
        public async Task ExecuteAsync(HttpListenerResponse response)
        {

            string html = HtmlTemplateRenderer.Render(_templateName, _model);

            byte[] buffer = Encoding.UTF8.GetBytes(html);

            response.StatusCode = 200;
            response.ContentType = "text/html; charset=utf-8";
            response.ContentLength64 = buffer.Length;

            using (var output = response.OutputStream)
            {
                await output.WriteAsync(buffer, 0, buffer.Length);
            }
        }
    }
}
