﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

        namespace CustomHttpServer.Framework.Attributes
    {
        [AttributeUsage(AttributeTargets.Parameter)]
        public class FromQueryAttribute : Attribute
        {

        }
    }
